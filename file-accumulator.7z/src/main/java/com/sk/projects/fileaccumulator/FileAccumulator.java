package com.sk.projects.fileaccumulator;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;

public class FileAccumulator {

	private static final String DESITINATION_FILE_NAME = "accumulated.txt";
	private static final String ENCODED_FILE_NAME = "base64encoded.txt";

	private static final String DESITINATION_DIR = "F:\\code\\target\\temp\\";
	private static final String DESITINATION_MERGED_PATH = DESITINATION_DIR + DESITINATION_FILE_NAME;
	private static final String DESITINATION_ENCODED_FILE_PATH = DESITINATION_DIR + ENCODED_FILE_NAME;

	private static final String SOURCE_DIR = "F:\\code\\source\\";

	public static void main(String[] args) {

		System.out.println("Getting stared in main..");

		accumulateAndWriteFiles();

		encodeToBase64();

		decodeFromBase64();
	}

	private static void accumulateAndWriteFiles() {

		String[] extensions = { "java", "xml" };

		try {
			Collection<File> files = FileUtils.listFiles(new File(SOURCE_DIR), extensions, true);

			List<String> allLines = new ArrayList<>();

			for (File file : files) {
				System.out.println("reading file: " + file.getName());
				allLines.add("//====================================== " + file.getName() + " =============================================");
				allLines.add("");

				// Reading data from existing file.
				allLines.addAll(Files.readAllLines(file.toPath(), StandardCharsets.ISO_8859_1));
				// Add some more data.
				allLines.add("");
				allLines.add("");
				// Write data into another file.
			}

			System.out.println("adding all files done..");

			Files.write(Paths.get(DESITINATION_MERGED_PATH), allLines);

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("All files merged at path: " + DESITINATION_MERGED_PATH);
	}

	private static void encodeToBase64() {
		try {
			byte[] bs = FileUtils.readFileToByteArray(new File(DESITINATION_MERGED_PATH));

			Base64 base64 = new Base64();
			String encodedString = new String(base64.encode(bs));

			Files.write(Paths.get(DESITINATION_ENCODED_FILE_PATH), Arrays.asList(encodedString));

			System.out.println("encoded file written at path: " + DESITINATION_ENCODED_FILE_PATH);
		} catch (IOException e) {
			System.err.println("Exception occured in convertToBase64 " + e);
			e.printStackTrace();
		}
	}

	private static void decodeFromBase64() {
		try {
			byte[] bs = FileUtils.readFileToByteArray(new File(DESITINATION_ENCODED_FILE_PATH));

			String decodedString = new String(new Base64().decode(bs));

			System.out.println("decoded data is" + decodedString);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Tweet } from '../models/tweet.model';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class TweetService {
    private allTweetsEndpoint = 'http://localhost:8080/api/private/alltweets';

    constructor(private http: HttpClient) {}

    getAllTweets(): Observable<Tweet[]> {
        //return this.http.get<Tweet[]>(this.allTweetsEndpoint);
        return of(this.mockTweets);
    }

    private mockTweets: Tweet[] = [
        {
            tweetId: '1',
            content: 'this is my first tweet',
            isLiked: 'true',
            likeCount: 12,
            anonymous: false,
            dislikeCount: 0,
        },
        {
            tweetId: '2',
            content: 'this is my second tweet',
            isLiked: 'false',
            likeCount: 2,
            anonymous: false,
            dislikeCount: 0,
        },
        {
            tweetId: '3',
            content: 'this is my third tweet',
            isLiked: 'true',
            likeCount: 22,
            anonymous: false,
            dislikeCount: 0,
        },
    ];
}

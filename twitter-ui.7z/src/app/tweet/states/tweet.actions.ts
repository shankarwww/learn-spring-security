import {createAction, props} from '@ngrx/store';
import { Tweet } from '../models/tweet.model';

export const GetAllTweets = createAction('[Tweet] Get All Tweets');
export const GetAllTweetsSuccess = createAction('[Tweet] Get All Tweets Success', props<{tweets: Tweet[]}>());
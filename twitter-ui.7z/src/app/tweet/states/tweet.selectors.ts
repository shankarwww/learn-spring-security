import { createSelector, createFeatureSelector } from '@ngrx/store';
import { TweetStore, TweetState } from './tweet.store';

const selectTweetStore = (state: TweetStore) => state;

const tweetStoreSelector = createFeatureSelector<TweetState>('tweetStore');
export const loadAllTweets = createSelector(tweetStoreSelector, (state) => state.tweetStore.allTweets);

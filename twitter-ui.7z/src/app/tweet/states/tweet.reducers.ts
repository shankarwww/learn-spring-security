import { createReducer, props, State, Action, on } from '@ngrx/store';
import { TweetStore, TweetState } from './tweet.store';
import { GetAllTweetsSuccess } from './tweet.actions';

const initialTweetState = {} as TweetState;

export const tweetReducer = createReducer(
    initialTweetState,
    on(GetAllTweetsSuccess, (state, props) => {
        const data = {
            ...state.tweetStore,
            allTweets: props.tweets,
        };
        return { tweetStore: data };
    })
);

export function tweetReducerFn(state: TweetState | undefined, action: Action) {
    return tweetReducer(state, action);
}

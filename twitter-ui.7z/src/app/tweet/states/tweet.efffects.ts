import { TweetService } from '../services/tweet.service';
import { createEffect, ofType, Actions } from '@ngrx/effects';
import { GetAllTweets, GetAllTweetsSuccess } from './tweet.actions';
import { switchMap, map } from 'rxjs/operators';
import { Tweet } from '../models/tweet.model';
import { Injectable } from '@angular/core';

@Injectable()
export class TweetEffects {
    constructor(private actions$: Actions, private tweetService: TweetService) {}

    allTweets$ = createEffect(() =>
        this.actions$.pipe(
            ofType(GetAllTweets),
            switchMap((actionName) => {
                console.log('the action type is', actionName);
                return this.tweetService.getAllTweets().pipe(map((tweetList: Tweet[]) => GetAllTweetsSuccess({ tweets: tweetList })));
            })
        )
    );
}

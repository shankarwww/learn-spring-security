import { Tweet } from '../models/tweet.model';
import { AppState } from '../../app-state';

export class TweetStore {
    allTweets: Tweet[];
    newTweet: Tweet;
    editTeeet: Tweet;
}

export class TweetState extends AppState {
    tweetStore: TweetStore;
}

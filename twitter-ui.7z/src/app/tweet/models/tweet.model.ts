import { KeyValue } from './keyvalue.model';
import { CommentModel } from './comment.model';

export class Tweet {
    tweetId?: string;
    content: string;
    userVotes?: number;
    allVotes?: number;
    anonymous: boolean;
    userId?: string;
    userFullName?: string;
    isLiked?: string;
    likeCount: number = 0;
    dislikeCount: number = 0;
    edit?: boolean;
    createdOn?: Date;
    modifiedOn?: Date;
    archived?: boolean;
    archiveSetId?: string;
    archiveSetName?: string;
    addUpdateComment?: CommentModel;
    commentList?: CommentModel[];
    keyValue?: KeyValue;
}

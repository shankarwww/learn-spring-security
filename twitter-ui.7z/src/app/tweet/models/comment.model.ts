export class CommentModel {
    constructor(boardId: string, cardId: string, commentId: string,
        content: string, userId: string, userFullName: string,
        anonymous: boolean) {
        this.boardId = boardId;
        this.cardId = cardId;
        this.commentId = commentId;
        this.content = content;
        this.userId = userId;
        this.userFullName = userFullName;
        this.anonymous = anonymous;
    }
    boardId: string;
    cardId: string;
    commentId: string;
    content: string;
    userId?: string;
    userFullName?: string;
    projectId?: string;
    anonymous: boolean;
    edit?: boolean;
}

import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, from } from 'rxjs';
import { Tweet } from '../../models/tweet.model';
import { GetAllTweets } from '../../states/tweet.actions';
import { loadAllTweets } from '../../states/tweet.selectors';
import { TweetStore } from '../../states/tweet.store';
import { AppState } from 'src/app/app-state';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
    tweets$: Observable<Tweet[]>;

    constructor(private store: Store<AppState>) {}

    ngOnInit(): void {
        this.loadAllTweets();
    }

    private loadAllTweets(): void {
        this.store.dispatch(GetAllTweets());

        this.tweets$ = this.store.select(loadAllTweets);
        this.store.select(loadAllTweets).subscribe((data) => {
            console.log('store data is', data);
        });
    }
}

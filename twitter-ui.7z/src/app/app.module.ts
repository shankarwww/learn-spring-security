import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './tweet/components/dashboard/dashboard.component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { tweetReducerFn } from './tweet/states/tweet.reducers';
import { TweetEffects } from './tweet/states/tweet.efffects';

@NgModule({
    declarations: [AppComponent, DashboardComponent],
    imports: [
        BrowserModule,
        HttpClientModule,
        AppRoutingModule,
        //StoreModule.forRoot({ tweetState: tweetReducerFn }),
        StoreModule.forRoot({}),
        StoreModule.forFeature('tweetStore', tweetReducerFn),
        EffectsModule.forRoot([TweetEffects]),
        StoreDevtoolsModule.instrument(),
    ],
    providers: [],
    bootstrap: [AppComponent],
})
export class AppModule {}
